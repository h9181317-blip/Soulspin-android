# SoulSpin Android starter (v0.1)

A small native Android starter app for the SoulSpin concept:
- fluid-inspired cosmic visual panel
- tap-to-reveal original spiritual reflections
- looping, locally bundled ambient audio with a manual toggle
- GitHub Actions workflow to build a debug APK in the cloud

## Build from an Android phone
1. Create/sign in to a GitHub account in your phone browser.
2. Create a new repository named `soulspin-android`.
3. Upload the contents of this ZIP to the repository (extract the ZIP first; upload the files/folders, not the ZIP itself).
4. Open the repository's **Actions** tab and enable Actions if prompted.
5. Select **Build SoulSpin Android APK** and tap **Run workflow**, or push to `main`.
6. When the run finishes, open the workflow run and download the `SoulSpin-debug-apk` artifact.
7. Extract the downloaded artifact ZIP and install `app-debug.apk`. Android may ask you to allow installs from your browser/files app.

## Important notes
- This is an early starter, not a store-ready product.
- No advertising, billing, accounts, analytics, or cloud sync are implemented yet.
- The sound is a synthesized audible ambient loop inspired by a contemplative soundscape. It does not reproduce the electromagnetic Schumann resonance itself.
- Audio pauses when the app leaves the foreground.
- Keep any future signing keys and passwords private. Never paste GitHub access tokens into chat or share them with anyone.
