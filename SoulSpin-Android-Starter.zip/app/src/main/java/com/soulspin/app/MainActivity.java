package com.soulspin.app;

import android.app.Activity;
import android.os.Bundle;
import android.media.MediaPlayer;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import java.util.Random;

public class MainActivity extends Activity {
    private MediaPlayer player;
    private boolean soundOn = false;
    private final Random random = new Random();
    private final String[][] reflections = {
        {"Within stillness, a new way of seeing begins.", "A SoulSpin reflection"},
        {"You do not have to see the whole path to take one gentle step.", "A SoulSpin reflection"},
        {"Let wonder be the doorway, and kindness the way through.", "A SoulSpin reflection"},
        {"Like the stars, you can shine without asking the night for permission.", "A SoulSpin reflection"},
        {"Return to this moment. It is where your life is unfolding.", "A SoulSpin reflection"},
        {"The roots of peace grow quietly beneath the surface.", "A SoulSpin reflection"},
        {"Listen closely: even silence can make room for insight.", "A SoulSpin reflection"}
    };
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        setContentView(R.layout.activity_main);
        Button spin = findViewById(R.id.spin);
        Button sound = findViewById(R.id.sound);
        TextView quote = findViewById(R.id.quote);
        TextView attribution = findViewById(R.id.attribution);
        spin.setOnClickListener(v -> {
            int i = random.nextInt(reflections.length);
            quote.setText(reflections[i][0]);
            attribution.setText("— " + reflections[i][1]);
            quote.setAlpha(0.25f);
            quote.animate().alpha(1f).setDuration(500).start();
        });
        sound.setOnClickListener(v -> {
            if (!soundOn) startSound();
            else stopSound();
            sound.setText(soundOn ? "♫  Ambient sound is on · Tap to stop" : "♫  Start ambient sound");
        });
    }
    private void startSound() {
        try {
            if (player == null) {
                player = MediaPlayer.create(this, R.raw.ambient_loop);
                if (player == null) return;
                player.setLooping(true);
            }
            player.start();
            soundOn = true;
        } catch (Exception e) { soundOn = false; }
    }
    private void stopSound() {
        if (player != null && player.isPlaying()) player.pause();
        soundOn = false;
    }
    @Override protected void onPause() {
        super.onPause();
        // Keep audio scoped to the foreground app experience.
        if (player != null && player.isPlaying()) player.pause();
        soundOn = false;
        Button sound = findViewById(R.id.sound);
        if (sound != null) sound.setText("♫  Start ambient sound");
    }
    @Override protected void onDestroy() {
        if (player != null) { player.release(); player = null; }
        super.onDestroy();
    }
}
